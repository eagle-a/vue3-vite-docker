/// <reference types="@lincy/utils/dist/index.d.ts" />

export {}
