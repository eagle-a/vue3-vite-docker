const url = 'http://1.94.109.75:4000'

export default url
