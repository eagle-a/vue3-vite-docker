/// <reference types="@lincy/utils" />
/// <reference types="vite/client" />
/// <reference types="unplugin-vue-macros/macros-global" />
/// <reference types="vite-plugin-pwa/client" />

export {}
