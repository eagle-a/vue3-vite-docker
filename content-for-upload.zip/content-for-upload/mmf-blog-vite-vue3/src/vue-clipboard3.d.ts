declare module 'vue-clipboard3'
