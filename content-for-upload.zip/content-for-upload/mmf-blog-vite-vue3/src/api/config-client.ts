const config = {
    api: '/api/',
    timeout: 30000,
}
export default config
