const url = 'http://0.0.0.0:4000'

export default url
