<template>
    <div class="card card-other">
        <div class="card-content">
            <ul class="other-item">
                <li>当前版本: v1.0.0</li>
                <li>项目开源地址: <a href="https://github.com/eagle-a/vue3-vite-docker" target="_blank">vue3-vite-docker</a></li>
                <li>网站备案号: <a href="http://beian.miit.gov.cn" target="_blank">none</a></li>
            </ul>
        </div>
    </div>
</template>

<script setup lang="ts">
defineOptions({
    name: 'AsideOther',
})
</script>
