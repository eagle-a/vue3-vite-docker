import { webConfig } from '@lincy/base-config'

export default webConfig()
