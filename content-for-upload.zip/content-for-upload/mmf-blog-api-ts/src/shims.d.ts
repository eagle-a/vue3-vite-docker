declare module 'markdown-it-toc-and-anchor'
declare module 'base64-img'
declare module 'baidu-aip-sdk'
declare module 'connect-multiparty'
