exports.apiId = 'eagle'
exports.secret = 'jllgshllWEUJHGHYJkjsfjds90'


