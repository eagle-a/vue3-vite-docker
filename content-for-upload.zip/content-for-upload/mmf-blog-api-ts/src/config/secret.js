exports.secretClient = 'jllgshllWEUJHGHYJkjsfjds90'
exports.secretServer = 'secret'
