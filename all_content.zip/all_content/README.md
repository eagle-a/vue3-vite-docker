# vue3-vite-docker
开发部署一条龙

# 部分需要修改的地方

nginx的serve_name

nginx的反向代理ip

docker-compose.yml的data路径

记得创建mongodata文件夹
